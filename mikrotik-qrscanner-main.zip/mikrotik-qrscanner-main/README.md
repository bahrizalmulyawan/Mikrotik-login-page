myqr.html

let html5QrCode=new Html5Qrcode("reader");
let currentCameraId=null;

/* DOMAIN ALLOWLIST */
/* change this domain */



const ALLOWED_DOMAINS=[
"namawifi.net",

];



ganti ini sesusai domain yang ada


https://bahrizalmulyawan.github.io/qrcode/livedemo
